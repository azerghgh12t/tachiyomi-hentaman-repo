package eu.kanade.tachiyomi.extension.ar.hentaman

import eu.kanade.tachiyomi.multisrc.madara.Madara
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.FilterList
import org.jsoup.nodes.Element

class Hentaman : Madara("Hentaman", "https://hentaman.net", "ar") {

    override fun getFilterList(): FilterList {
        return super.getFilterList() // تفعيل فلاتر Madara الجاهزة
    }

    override val useLatestChapterDate = true

    override fun chapterFromElement(element: Element): SChapter {
        val chapter = super.chapterFromElement(element)
        chapter.name = element.selectFirst("a")?.text()?.trim() ?: "Chapter"
        chapter.date_upload = element.selectFirst(".chapter-release-date")?.text()?.let {
            parseChapterDate(it)
        } ?: 0L
        return chapter
    }
}
